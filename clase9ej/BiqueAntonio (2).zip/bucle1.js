let i=0;
let sumando=3;
while (sumando <=10000)
{
    i=sumando+i;
    sumando= sumando+3;
    
}
console.log(`La suma es: ${i}`)
alert(i);