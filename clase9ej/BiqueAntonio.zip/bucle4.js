let x= 3
let y= 5
let suma2= 0
let suma3= 0

while(x<=10000||y<=10000)
{
    if (x % 5==0)
    {
        suma2=suma2
    }
    else{suma2=x+suma2}
    x=x+3

    if(y%3==0)
    {
        suma3=suma3
    }
    else{suma3= y+suma3}
    y=y+5
}
let total= suma2+suma3

alert(`${total}`)
